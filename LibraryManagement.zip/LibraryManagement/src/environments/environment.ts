export const environment = {
    apiUrl:'http://192.168.0.111:8083//',
    production: false
};
