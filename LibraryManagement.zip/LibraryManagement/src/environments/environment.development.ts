export const environment = {
    apiUrl:'http://localhost:7131/',
    production: false
};
