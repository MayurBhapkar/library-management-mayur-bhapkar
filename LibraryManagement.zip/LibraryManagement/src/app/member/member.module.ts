import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { MemberRoutingModule } from './member-routing.module';


@NgModule({
  declarations: [],
  imports: [
    CommonModule,
    MemberRoutingModule
  ]
})
export class MemberModule { }
