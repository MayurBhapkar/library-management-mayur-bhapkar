﻿namespace LibraryManagementApi.Dto
{
    public class userDto
    {

        public string unm { get; set; }
        public string pwd { get; set; }
    }
}
