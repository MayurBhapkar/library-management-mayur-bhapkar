﻿namespace LibraryManagementApi.Dto
{
    public class BetweenDateDto
    {
        public DateTime startdt { get; set; }
        public DateTime enddt { get; set; }
    }
}
